package com.music.bitchord.data.spotify

import com.music.bitchord.data.Http
import com.music.bitchord.data.YtMusicRepository
import com.music.bitchord.data.model.SearchFilter
import com.music.bitchord.data.model.SearchResult
import com.music.bitchord.data.model.Song
import com.music.bitchord.data.sources.TrackMatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull
import okhttp3.Request
import java.util.Locale

/** Public-URL Spotify playlist import. No Spotify account or Client ID is needed. */
object SpotifyPlaylistImporter {
    private const val API_BASE = "https://spotify.xwolf.space/api/playlist/"
    private val json = Json { ignoreUnknownKeys = true }
    private val playlistId = Regex("(?:open\\.spotify\\.com/(?:embed/)?playlist/|spotify:playlist:)([A-Za-z0-9]+)")

    data class Track(val title: String, val artist: String, val durationMs: Long? = null)
    data class Result(val playlistName: String, val tracks: List<Track>)

    fun extractPlaylistId(input: String): String? = playlistId.find(input.trim())?.groupValues?.getOrNull(1)

    suspend fun fetch(url: String): kotlin.Result<Result> = withContext(Dispatchers.IO) {
        runCatching {
            val id = extractPlaylistId(url) ?: error("Paste a valid Spotify playlist link")
            val request = Request.Builder().url(API_BASE + id).get()
                .header("Accept", "application/json")
                .build()
            Http.client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) error("Spotify playlist service returned ${response.code}")
                val body = response.body?.string().orEmpty()
                val root = json.parseToJsonElement(body)
                val tracks = mutableListOf<Track>()
                collectTracks(root, tracks)
                if (tracks.isEmpty()) error("No tracks found in this playlist")
                val name = findPlaylistName(root) ?: "Spotify Playlist"
                Result(name, tracks.distinctBy { it.title.lowercase(Locale.ROOT) + "|" + it.artist.lowercase(Locale.ROOT) })
            }
        }
    }

    suspend fun match(track: Track): Song? {
        val target = TrackMatcher.Target(track.title, track.artist, track.durationMs?.div(1000)?.toInt())
        for (query in TrackMatcher.queries(target)) {
            val candidates = YtMusicRepository.search(query, SearchFilter.SONGS).getOrNull().orEmpty().mapNotNull {
                when (it) {
                    is SearchResult.Track -> it.song
                    is SearchResult.TopTrack -> it.song
                    else -> null
                }
            }
            TrackMatcher.best(candidates, target)?.let { return it }
        }
        return null
    }

    private fun collectTracks(element: JsonElement, out: MutableList<Track>) {
        when (element) {
            is JsonArray -> element.forEach { collectTracks(it, out) }
            is JsonObject -> {
                val title = string(element, "name", "title")
                val artists = element["artists"]
                val artist = when (artists) {
                    is JsonArray -> artists.mapNotNull { (it as? JsonObject)?.let { obj -> string(obj, "name", "title") } }.joinToString(", ")
                    else -> string(element, "artist", "artistName")
                }
                val looksLikeTrack = !title.isNullOrBlank() && !artist.isNullOrBlank() &&
                    (element.containsKey("duration_ms") || element.containsKey("durationMs") || element.containsKey("artists"))
                if (looksLikeTrack) {
                    val duration = element["duration_ms"]?.asLong() ?: element["durationMs"]?.asLong()
                    out += Track(title!!, artist!!, duration)
                }
                element.values.forEach { collectTracks(it, out) }
            }
            else -> Unit
        }
    }

    private fun findPlaylistName(element: JsonElement): String? {
        when (element) {
            is JsonObject -> {
                val type = string(element, "type")
                val name = string(element, "name", "title")
                if (type == "playlist" && !name.isNullOrBlank()) return name
                element.values.forEach { findPlaylistName(it)?.let { found -> return found } }
            }
            is JsonArray -> element.forEach { findPlaylistName(it)?.let { found -> return found } }
            else -> Unit
        }
        return null
    }

    private fun string(obj: JsonObject, vararg keys: String): String? =
        keys.asSequence().mapNotNull { (obj[it] as? JsonPrimitive)?.contentOrNull }.firstOrNull { it.isNotBlank() }

    private fun JsonElement.asLong(): Long? = (this as? JsonPrimitive)?.contentOrNull?.toLongOrNull()
}
