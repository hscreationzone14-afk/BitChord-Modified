package com.music.bitchord.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.music.bitchord.data.YtMusicRepository
import com.music.bitchord.data.model.PlaylistPrivacy
import com.music.bitchord.data.spotify.SpotifyPlaylistImporter
import kotlinx.coroutines.launch

@Composable
fun SpotifyImportDialog(
    onDismiss: () -> Unit,
    onImported: () -> Unit,
    signedIn: Boolean,
) {
    var url by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    AlertDialog(
        onDismissRequest = { if (!busy) onDismiss() },
        title = { Text("Import Spotify Playlist") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    "Paste a public Spotify playlist link. No Spotify login or Premium is required.",
                    style = MaterialTheme.typography.bodyMedium,
                )
                OutlinedTextField(
                    value = url,
                    onValueChange = { url = it },
                    enabled = !busy,
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("https://open.spotify.com/playlist/...") },
                )
                status?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
                if (!signedIn) {
                    Text(
                        "Sign in to YouTube Music first so BitChord can create the imported playlist.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
                if (busy) CircularProgressIndicator()
            }
        },
        confirmButton = {
            Button(
                enabled = !busy && signedIn && SpotifyPlaylistImporter.extractPlaylistId(url) != null,
                onClick = {
                    busy = true
                    status = "Reading Spotify playlist…"
                    scope.launch {
                        val fetched = SpotifyPlaylistImporter.fetch(url)
                        fetched.fold(
                            onSuccess = { playlist ->
                                val matched = mutableListOf<com.music.bitchord.data.model.Song>()
                                playlist.tracks.forEachIndexed { index, track ->
                                    status = "Matching ${index + 1}/${playlist.tracks.size}: ${track.title}"
                                    SpotifyPlaylistImporter.match(track)?.let { matched += it }
                                }
                                if (matched.isEmpty()) {
                                    status = "No tracks could be matched on YouTube Music."
                                    busy = false
                                } else {
                                    status = "Creating playlist (${matched.size}/${playlist.tracks.size} matched)…"
                                    YtMusicRepository.createPlaylist(
                                        playlistName(playlist.playlistName),
                                        PlaylistPrivacy.PRIVATE,
                                        matched.distinctBy { it.videoId }.map { it.videoId },
                                    ).fold(
                                        onSuccess = {
                                            status = "Imported ${matched.size}/${playlist.tracks.size} tracks."
                                            busy = false
                                            onImported()
                                            onDismiss()
                                        },
                                        onFailure = {
                                            status = it.message ?: "Could not create the playlist."
                                            busy = false
                                        },
                                    )
                                }
                            },
                            onFailure = {
                                status = it.message ?: "Could not read this Spotify playlist."
                                busy = false
                            },
                        )
                    }
                },
            ) { Text("Import") }
        },
        dismissButton = {
            TextButton(enabled = !busy, onClick = onDismiss) { Text("Cancel") }
        },
    )
}

private fun playlistName(name: String): String = name.trim().ifBlank { "Spotify Import" }.take(150)
