package com.music.bitchord.ui.player

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.sin

/** Echo-style animated sine progress bar used only for the music playhead. */
@Composable
fun WavyProgressBar(
    value: Float,
    isPlaying: Boolean,
    onValueChange: (Float) -> Unit,
    onValueChangeFinished: (() -> Unit)? = null,
    modifier: Modifier = Modifier,
) {
    val transition = rememberInfiniteTransition(label = "wavyProgress")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = (PI * 2).toFloat(),
        animationSpec = infiniteRepeatable(
            tween(1100, easing = LinearEasing),
            repeatMode = RepeatMode.Restart,
        ),
        label = "wavePhase",
    )
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(30.dp)
            .pointerInput(Unit) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    onValueChange((down.position.x / size.width).coerceIn(0f, 1f))
                    while (true) {
                        val event = awaitPointerEvent()
                        val pointer = event.changes.firstOrNull { it.id == down.id } ?: break
                        if (!pointer.pressed) {
                            pointer.consume()
                            break
                        }
                        onValueChange((pointer.position.x / size.width).coerceIn(0f, 1f))
                        pointer.consume()
                    }
                    onValueChangeFinished?.invoke()
                }
            },
    ) {
        Canvas(Modifier.fillMaxWidth().height(30.dp)) {
            val progress = value.coerceIn(0f, 1f)
            val y = size.height / 2f
            val amplitude = 6f
            val wavelength = 28f
            val step = 2f
            val playedEnd = size.width * progress

            // Unplayed portion: Echo's straight, pale baseline.
            drawLine(
                color = Color.White.copy(alpha = 0.30f),
                start = Offset(0f, y),
                end = Offset(size.width, y),
                strokeWidth = 2f,
            )

            // Played portion: a soft sine wave. Phase only moves while playing.
            val actualPhase = if (isPlaying) phase else 0f
            var previous: Offset? = null
            var x = 0f
            while (x <= playedEnd) {
                val wave = sin((x / wavelength) * (PI * 2.0) + actualPhase).toFloat() * amplitude
                val point = Offset(x, y + wave)
                previous?.let {
                    drawLine(
                        color = Color(0xFF63D77A),
                        start = it,
                        end = point,
                        strokeWidth = 3.2f,
                    )
                }
                previous = point
                x += step
            }

            // Current-position thumb.
            drawCircle(
                color = Color.White,
                radius = 5.5f,
                center = Offset(playedEnd, y),
            )
        }
    }
}
